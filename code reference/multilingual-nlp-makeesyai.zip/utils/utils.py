import torch


def get_label2id_vocab(data):
    """a vocab (dict) with word: idx"""
    labels2idx = {'PAD': 0, 'UNK': 1}
    idx = len(labels2idx)
    for line in data:
        for l in line:
            if l not in labels2idx:
                labels2idx[l] = idx
                idx += 1
    return labels2idx


def get_label_ids(data, labels2ids):
    labels_ids = []
    for line in data:
        label_ids = []
        for l in line:
            # if find l, return it's id else return O's id, but won't happen
            label_ids.append(labels2ids.get(l, labels2ids.get('O')))
        labels_ids.append(label_ids)
    return labels_ids


def subword2word_embeddings(tokenizer, subword_embeddings, sentences, offset):
    """将embedding的序列逐个根据源sentences缩短为对应长度"""
    pooling = 'mean'
    sentence_embeddings = []
    for sentence, embedding in zip(sentences, subword_embeddings):
        subword_offest = offset
        true_embeddings = []
        words = sentence.split()
        for word in words:
            num_subwords = len(tokenizer.tokenize(word))
            word_embeddings = embedding[subword_offest:subword_offest + num_subwords]
            # 一个词被拆分了，就要选择其中一个embedding，于是有三种方法选择源词的对用的编码形式
            if not isinstance(word_embeddings, torch.Tensor):
                word_embeddings = torch.from_numpy(word_embeddings)
            if pooling == 'first':
                final_embeddings = word_embeddings[0]
            elif pooling == 'last':
                final_embeddings = word_embeddings[-1]
            else:
                final_embeddings = torch.mean(word_embeddings, dim=0)
            true_embeddings.append(final_embeddings)
            subword_offest += num_subwords
        sentence_embeddings.append(torch.stack(true_embeddings))
    return sentence_embeddings
