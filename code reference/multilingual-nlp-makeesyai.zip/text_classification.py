import os
import time
import torch
import pandas
import sklearn
from sentence_transformers import SentenceTransformer
from torch import nn, optim
from torch.nn import functional as F
from torch.utils.data import TensorDataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from tqdm import tqdm

"""
Models:
1. 'distilbert-base-nli-mean-tokens'
2. 'quora-distilbert-multilingual' (multilingual)
Steps:
1. Create pytorch model for text classification (explain each step with running the intermediate code)
2. Add Testing with training data using random model
3. Add Optimizer (Adam) and Loss function (CrossEntropy)
4. Add training Loop with logging loss
5. Add final evaluation code
"""


class Classsifier(nn.Module):
    def __init__(self, embedding_dim, num_labels, dropout):
        super(Classsifier, self).__init__()
        self.embedding_dim = embedding_dim
        self.num_labels = num_labels
        self.dropout = dropout

        self.dp = nn.Dropout(self.dropout)
        self.ff = nn.Linear(self.embedding_dim, self.num_labels)

    def forward(self, input_embeddings):
        tensor = self.dp(input_embeddings)
        tensor = self.ff(tensor)  # feed forward
        return tensor, F.softmax(tensor, dim=-1)  # model_output[num_input, num_labels] and probability after softmax


if __name__ == '__main__':
    # Sentences we want sentence embeddings for
    data_df = pandas.read_csv('data/data_en_hi_de_fr.csv')
    data_df.dropna(inplace=True)  # delete lines with NaN value inplace (with no return)
    data_df.drop_duplicates(inplace=True)
    data_df.rename(columns={
        "Category": "labels",
        "Message": "text"
    }, inplace=True)
    # print(data_df.head())

    # generate labels encoding and split
    le = sklearn.preprocessing.LabelEncoder()
    le.fit(data_df.labels)
    data_df["labels"] = le.transform(data_df.labels)
    train_X, test_X, train_y, test_y = \
        train_test_split(data_df.text, data_df.labels, stratify=data_df.labels, test_size=0.15, random_state=123)
    train_X_de, test_X_de, train_y_de, test_y_de = \
        train_test_split(data_df.text_hi, data_df.labels, stratify=data_df.labels, test_size=0.15, random_state=123)
    # print(train_X.describe())
    # print(test_X.describe())
    print(type(train_X))
    sentences = train_X.tolist()
    test_sentences = test_X_de.tolist()
    labels = torch.tensor(train_y.tolist())
    test_labels = torch.tensor(test_y_de.tolist())

    os.environ['TORCH_HOME'] = './models/pretrained'  # setting the environment variable
    encoder = SentenceTransformer('quora-distilbert-multilingual')
    print('Encoding segments...')
    start = time.time()
    embedding = encoder.encode(sentences, convert_to_tensor=True)
    test_embedding = encoder.encode(test_sentences, convert_to_tensor=True)
    print(f"Encoding completed in {time.time() - start} seconds.")
    num_samples, embedding_dim = embedding.size()
    n_labels = labels.unique().shape[0]

    datasets = TensorDataset(embedding, labels)
    train_iter = DataLoader(datasets, batch_size=16, shuffle=True)
    classifier = Classsifier(embedding_dim, n_labels, dropout=0.01)
    optimizer = optim.Adam(classifier.parameters())
    loss_fn = nn.CrossEntropyLoss()

    num_epoch = 10
    for epoch in range(num_epoch):
        total_loss = 0
        for X, y in tqdm(train_iter):
            optimizer.zero_grad()
            y_hat, _ = classifier(X)
            loss = loss_fn(y_hat, y)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        print(f"total loss {total_loss:.2f}")
    torch.save(classifier.state_dict(), 'models/text_cls.pth')

    model = classifier
    model.load_state_dict(torch.load('./models/text_cls.pth'))
    with torch.no_grad():
        _, prob = model(test_embedding)
        prediction = torch.argmax(prob, dim=-1)
        results = classification_report(prediction, test_labels)
        print(results)

