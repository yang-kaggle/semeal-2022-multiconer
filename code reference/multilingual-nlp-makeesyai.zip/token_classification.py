import os

import pandas
import torch
import numpy
import warnings
from sentence_transformers import SentenceTransformer
from torch import nn, optim, tensor
from torch.nn import functional as F
from torch.utils.data import DataLoader, TensorDataset
from transformers import XLNetTokenizer, T5Tokenizer, GPT2Tokenizer
from tqdm import tqdm
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.exceptions import UndefinedMetricWarning
from utils import *

warnings.filterwarnings("ignore", category=UndefinedMetricWarning)

# Models:
# SBERT: https://www.sbert.net/docs/pretrained_models.html
# Huggingface: https://huggingface.co/models


class NEDataset(torch.utils.data.Dataset):
    def __init__(self, encodings, labels=None):
        self.encodings = encodings
        self.labels = labels
        self.tensors = [self.encodings, self.labels]

    def __getitem__(self, idx):
        return tuple(tensor[idx] for tensor in self.tensors)

    def __len__(self):
        return len(self.labels)


class Classifier(nn.Module):
    def __init__(self, embedding_dim, num_labels, dropout):
        super(Classifier, self).__init__()
        self.embedding_dim = embedding_dim
        self.num_labels = num_labels

        self.dropout = nn.Dropout(dropout)
        self.ff = nn.Linear(self.embedding_dim, num_labels)

    def forward(self, inputs):
        tensor = self.dropout(inputs)
        tensor = self.ff(tensor)
        tensor = tensor.view(-1, self.num_labels)
        predict = F.softmax(tensor, dim=-1)
        return tensor, predict


if __name__ == '__main__':
    # load raw data
    df = pandas.read_csv('./data/wiki-ner/en/train.csv', sep='\t')
    raw_sentences = df.text.tolist()[:5000]
    raw_labels = df.labels.tolist()[:5000]
    train_sentences = []
    train_labels = []

    # check if sentences and labels have consistent length
    for text, label in zip(raw_sentences, raw_labels):
        if len(text.split()) < 80 and len(text.split()) == len(label.split()):
            train_sentences.append(text)
            train_labels.append(label)

    # sentences will split later at encoding
    a = [l.split() for l in train_labels]
    train_labels = a

    df = pandas.read_csv('./data/wiki-ner/en/test.csv', sep='\t')
    raw_sentences = df.text.tolist()[:1000]
    raw_labels = df.labels.tolist()[:1000]
    test_sentences = []
    test_labels = []
    for text, label in zip(raw_sentences, raw_labels):
        if len(text.split()) == len(label.split()):
            test_sentences.append(text)
            test_labels.append(label)
    # sentences will split later at encoding
    a = [l.split() for l in test_labels]
    test_labels = a
    # split train and test set
    # train_sentences, test_sentences, train_labels, test_labels = train_test_split(sentences[:5000],
    #                                                                               encoded_labels[:5000],
    #                                                                               test_size=0.1,
    #                                                                               shuffle=True)

    labels2ids = get_label2id_vocab(train_labels)
    ids2labels = dict([(labels2ids[key], key) for key in labels2ids])
    train_labels = get_label_ids(train_labels, labels2ids)
    test_labels = get_label_ids(test_labels, labels2ids)

    os.environ['TORCH_HOME'] = './models/pretrained'  # setting the environment variable
    encoder = SentenceTransformer('quora-distilbert-multilingual')  # 'distilbert-multilingual-nli-stsb-quora-ranking'
    tokenizer = encoder.tokenizer
    # print(type(tokenizer))
    # print(tokenizer.tokenize(sentences[3]))  # tokenized result

    # by default para output_value is 'sentence embeddings'
    # token_embedding return list(size is num_samples) of tensor[num_subwords, embedding_dim]
    train_embeddings = encoder.encode(train_sentences,
                                      output_value='token_embeddings',
                                      show_progress_bar=True,
                                      convert_to_tensor=True)

    test_embeddings = encoder.encode(test_sentences,
                                     output_value='token_embeddings',
                                     show_progress_bar=True,
                                     convert_to_tensor=True)
    _, embedding_dim = train_embeddings[0].size()
    num_embeddings = len(train_embeddings)
    num_labels = len(labels2ids)

    # subwords to true word embedding with 3 methods(first, last, mean)
    # most models have an initial BOS/CLS (begin of sentence/classifcation) token, except for CLNet, T5 and GPT2
    offset = 1
    if type(tokenizer) in [XLNetTokenizer, T5Tokenizer, GPT2Tokenizer]:
        offset = 0

    # 这部分简单来说就是tokenizer和embedding把单词拆分并编码，原来多少个词就多个embedding
    train_embeddings = subword2word_embeddings(tokenizer, train_embeddings, train_sentences, offset)
    test_embeddings = subword2word_embeddings(tokenizer, test_embeddings, test_sentences, offset)

    max_length = max([len(x) for x in train_embeddings])
    pad_id = tokenizer.pad_token_id
    pad_id_labels = labels2ids['PAD']

    padded_labels = pad_id_labels * numpy.ones((len(train_embeddings), max_length))
    padded_embeddings = list()
    for idx, embeddings in enumerate(train_embeddings):
        curr_len = embeddings.shape[0]  # num_subwords
        padded_labels[idx][:curr_len] = train_labels[idx]

        padded_embeddings += [emb for emb in embeddings]
        num_pads = max_length - curr_len

        if num_pads > 0:
            padded_embeddings.append(
                torch.full(size=(num_pads * embedding_dim,), fill_value=pad_id, dtype=torch.float32))
    train_embeddings = torch.cat(padded_embeddings).reshape(len(train_embeddings), max_length, embedding_dim)
    train_labels = torch.LongTensor(padded_labels)
    print(train_embeddings.shape, train_labels.shape)
    tmp = torch.Tensor(test_embeddings[0])
    print(tmp.shape)

    net = Classifier(embedding_dim, num_labels, dropout=0.01)
    loss_fn = nn.CrossEntropyLoss()
    optimizer = optim.Adam(net.parameters())

    dataset = NEDataset(train_embeddings, train_labels)
    train_iter = DataLoader(dataset, batch_size=32)

    num_epoch = 50
    for epoch in range(num_epoch):
        total_loss = 0
        for X, y in tqdm(train_iter):
            optimizer.zero_grad()
            y = torch.LongTensor(y)
            y_hat, _ = net(X)
            print(y_hat.shape, y.shape)
            loss = loss_fn(y_hat, y.view(-1))
            loss.backward()
            optimizer.step()
            total_loss += loss
        print(f"loss {total_loss / num_embeddings:.2f}")
    torch.save(net.state_dict(), './models/token_cls.pth')

    model = net
    model.load_state_dict(torch.load('./models/token_cls.pth'))

    # for emb, label in zip(sentence_embeddings, labels):
    #     _, predict_prob = model(emb)
    #     predict_labels = torch.argmax(predict_prob, dim=-1)
    #     print(predict_labels.tolist())
    #     print(label)
    # exit(0)
    with torch.no_grad():
        prediction = []
        truevalue = []
        for sentence_embedding, sentence_label in zip(test_embeddings, test_labels):
            _, prob = model(sentence_embedding)
            prediction.extend(torch.argmax(prob, dim=-1).tolist())
            truevalue.extend(sentence_label)
        # print(prediction, '\n', test_labels)
    # from sklearn.preprocessing import MultiLabelBinarizer
    #
    # prediction = MultiLabelBinarizer().fit_transform(prediction)
    # labels = MultiLabelBinarizer().fit_transform(test_labels)
    results = classification_report(prediction, truevalue)
    print(results)
